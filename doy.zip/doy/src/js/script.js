function display_1(e) {
    console.log(e)
    document.getElementsByClassName('modal')[0].style.display = 'block'
    document.getElementsByClassName('block_info_1_modal')[0].style.display = 'block'
}

function display_2(e) {
    console.log(e)
    document.getElementsByClassName('modal')[0].style.display = 'block'
    document.getElementsByClassName('block_info_2_modal')[0].style.display = 'block'
}

function display_3(e) {
    console.log(e)
    document.getElementsByClassName('modal')[0].style.display = 'block'
    document.getElementsByClassName('block_info_3_modal')[0].style.display = 'block'
}

function display_4(e) {
    console.log(e)
    document.getElementsByClassName('modal')[0].style.display = 'block'
    document.getElementsByClassName('block_info_4_modal')[0].style.display = 'block'
}

function display_5(e) {
    console.log(e)
    document.getElementsByClassName('modal')[0].style.display = 'block'
    document.getElementsByClassName('block_info_5_modal')[0].style.display = 'block'
}

function display_6(e) {
    console.log(e)
    document.getElementsByClassName('modal')[0].style.display = 'block'
    document.getElementsByClassName('block_info_6_modal')[0].style.display = 'block'
}

function display_7(e) {
    console.log(e)
    document.getElementsByClassName('modal')[0].style.display = 'block'
    document.getElementsByClassName('block_info_7_modal')[0].style.display = 'block'
}

function display_8(e) {
    console.log(e)
    document.getElementsByClassName('modal')[0].style.display = 'block'
    document.getElementsByClassName('block_info_8_modal')[0].style.display = 'block'
}

function display_9(e) {
    console.log(e)
    document.getElementsByClassName('modal')[0].style.display = 'block'
    document.getElementsByClassName('block_info_9_modal')[0].style.display = 'block'
}

function display_10(e) {
    console.log(e)
    document.getElementsByClassName('modal')[0].style.display = 'block'
    document.getElementsByClassName('block_info_10_modal')[0].style.display = 'block'
}
document.addEventListener("keydown", function(event) {
    if (event.key === "Escape") {
        document.getElementsByClassName('block_info_10_modal')[0].style.display = "none";
        document.getElementsByClassName('block_info_9_modal')[0].style.display = "none";
        document.getElementsByClassName('block_info_8_modal')[0].style.display = "none";
        document.getElementsByClassName('block_info_8_modal')[0].style.display = "none";
        document.getElementsByClassName('block_info_7_modal')[0].style.display = "none";
        document.getElementsByClassName('block_info_6_modal')[0].style.display = "none";
        document.getElementsByClassName('block_info_5_modal')[0].style.display = "none";
        document.getElementsByClassName('block_info_4_modal')[0].style.display = "none";
        document.getElementsByClassName('block_info_3_modal')[0].style.display = "none";
        document.getElementsByClassName('block_info_2_modal')[0].style.display = "none";
        document.getElementsByClassName('block_info_1_modal')[0].style.display = "none";
        document.getElementsByClassName('modal')[0].style.display = 'none';
    }
});